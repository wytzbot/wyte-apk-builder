#!/usr/bin/env node
/**
 * Builds ./app/twa-manifest.json directly (Bubblewrap's TWA manifest schema)
 * instead of relying on `bubblewrap init`'s interactive prompts. This is what
 * lets the workflow run fully unattended in CI.
 *
 * It tries to discover the site's own web app manifest for icons/name/colors,
 * then layers the workflow_dispatch inputs on top as overrides.
 */
import { mkdirSync, writeFileSync } from 'node:fs';

const env = process.env;
const appUrl = new URL(env.APP_URL);

async function findWebManifest(origin) {
  const candidates = ['/manifest.json', '/manifest.webmanifest', '/site.webmanifest'];
  for (const path of candidates) {
    try {
      const res = await fetch(new URL(path, origin), { redirect: 'follow' });
      if (res.ok) {
        const json = await res.json();
        console.log(`Found web manifest at ${path}`);
        return { url: new URL(path, origin).toString(), json };
      }
    } catch {
      // try the next candidate
    }
  }
  // Fall back to parsing <link rel="manifest"> out of the HTML
  try {
    const res = await fetch(origin);
    const html = await res.text();
    const match = html.match(/<link[^>]+rel=["']manifest["'][^>]+href=["']([^"']+)["']/i);
    if (match) {
      const manifestUrl = new URL(match[1], origin);
      const mRes = await fetch(manifestUrl);
      if (mRes.ok) {
        console.log(`Found web manifest via <link rel="manifest"> at ${manifestUrl}`);
        return { url: manifestUrl.toString(), json: await mRes.json() };
      }
    }
  } catch {
    // no manifest discoverable — that's fine, we fall back to overrides/defaults
  }
  return null;
}

function pickLargestIcon(icons = [], purposeFilter) {
  const candidates = icons.filter((i) => !purposeFilter || (i.purpose || '').includes(purposeFilter));
  const pool = candidates.length ? candidates : icons;
  if (!pool.length) return null;
  return pool
    .slice()
    .sort((a, b) => {
      const sizeOf = (s) => parseInt((s.sizes || '0x0').split('x')[0], 10) || 0;
      return sizeOf(b) - sizeOf(a);
    })[0];
}

function toAbsolute(url, base) {
  if (!url) return undefined;
  try {
    return new URL(url, base).toString();
  } catch {
    return undefined;
  }
}

const discovered = await findWebManifest(appUrl.origin);
const webManifest = discovered?.json ?? {};
const webManifestBase = discovered?.url ?? appUrl.toString();

const regularIcon = pickLargestIcon(webManifest.icons, 'any') || pickLargestIcon(webManifest.icons);
const maskableIcon = pickLargestIcon(webManifest.icons, 'maskable');

if (!env.ICON_URL && !regularIcon) {
  console.error(
    '❌ No icon available: the site has no discoverable web manifest with icons, and no icon_url input was provided.\n' +
    '   Fix: add a manifest.json with an "icons" array to the site, or pass the icon_url input.'
  );
  process.exit(1);
}

const enableNotifications = String(env.ENABLE_NOTIFICATIONS).toLowerCase() === 'true';

const twaManifest = {
  packageId: env.PACKAGE_NAME,
  host: appUrl.host,
  name: env.APP_NAME,
  launcherName: env.APP_NAME.slice(0, 30),
  display: env.DISPLAY_MODE || webManifest.display || 'standalone',
  orientation: env.ORIENTATION === 'default' ? undefined : env.ORIENTATION,
  themeColor: env.THEME_COLOR || webManifest.theme_color || '#4F46E5',
  navigationColor: env.THEME_COLOR || webManifest.theme_color || '#4F46E5',
  backgroundColor: env.BACKGROUND_COLOR || webManifest.background_color || '#0F172A',
  enableNotifications,
  startUrl: toAbsolute(env.START_URL || webManifest.start_url || '/', webManifestBase),
  iconUrl: env.ICON_URL || toAbsolute(regularIcon?.src, webManifestBase),
  maskableIconUrl: toAbsolute(maskableIcon?.src, webManifestBase),
  appVersionName: env.VERSION_NAME || '1.0.0',
  appVersionCode: parseInt(env.VERSION_CODE || '1', 10),
  signingKey: {
    path: '/home/runner/work/_temp/android.keystore',
    alias: env.KEY_ALIAS || 'wyte-release-key',
  },
  fallbackType: env.FALLBACK_TYPE || 'customtabs',
  splashScreenFadeOutDuration: 300,
  generatorApp: 'wyte-apk-builder',
  webManifestUrl: webManifestBase,
};

// Drop undefined keys so the JSON is clean.
for (const k of Object.keys(twaManifest)) {
  if (twaManifest[k] === undefined) delete twaManifest[k];
}

mkdirSync('./app', { recursive: true });
writeFileSync('./app/twa-manifest.json', JSON.stringify(twaManifest, null, 2));
console.log('✅ Wrote ./app/twa-manifest.json');
console.log(JSON.stringify(twaManifest, null, 2));

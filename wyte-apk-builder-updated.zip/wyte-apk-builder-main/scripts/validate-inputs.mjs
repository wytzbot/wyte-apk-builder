#!/usr/bin/env node
/**
 * Validates all workflow_dispatch inputs before any expensive build work happens.
 * Reads everything from env vars (set by the workflow step) and exits 1 with a
 * clear, human-readable message on the first problem found.
 */

const HEX_COLOR = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
const PACKAGE_NAME = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
const SEMVER_LOOSE = /^\d+(\.\d+){0,2}$/;

const errors = [];

function req(name) {
  const v = process.env[name];
  if (v === undefined || v.trim() === '') errors.push(`${name} is required but was empty.`);
  return v;
}

function check(condition, message) {
  if (!condition) errors.push(message);
}

const appUrl = req('APP_URL');
if (appUrl) {
  try {
    const u = new URL(appUrl);
    check(u.protocol === 'https:', `APP_URL must use https:// (got "${u.protocol}").`);
  } catch {
    errors.push(`APP_URL "${appUrl}" is not a valid URL.`);
  }
}

const appName = req('APP_NAME');
check(!appName || appName.length <= 45, 'APP_NAME must be 45 characters or fewer (Android launcher label limit).');

const packageName = req('PACKAGE_NAME');
if (packageName) {
  check(
    PACKAGE_NAME.test(packageName),
    `PACKAGE_NAME "${packageName}" is invalid. Must look like "com.example.app" (lowercase, dot-separated, each segment starts with a letter).`
  );
}

const versionName = process.env.VERSION_NAME || '';
check(!versionName || SEMVER_LOOSE.test(versionName), `VERSION_NAME "${versionName}" should look like 1.0 or 1.0.0.`);

const versionCode = process.env.VERSION_CODE || '';
check(
  /^\d+$/.test(versionCode) && Number(versionCode) > 0 && Number(versionCode) < 2100000000,
  `VERSION_CODE "${versionCode}" must be a positive whole number (Android versionCode is a 32-bit int).`
);

const orientation = process.env.ORIENTATION || 'default';
check(
  ['default', 'portrait', 'landscape'].includes(orientation),
  `ORIENTATION "${orientation}" must be one of: default, portrait, landscape.`
);

const themeColor = process.env.THEME_COLOR || '';
check(!themeColor || HEX_COLOR.test(themeColor), `THEME_COLOR "${themeColor}" must be a hex color like #4F46E5.`);

const backgroundColor = process.env.BACKGROUND_COLOR || '';
check(!backgroundColor || HEX_COLOR.test(backgroundColor), `BACKGROUND_COLOR "${backgroundColor}" must be a hex color like #0F172A.`);

const display = process.env.DISPLAY_MODE || 'standalone';
check(
  ['standalone', 'fullscreen', 'minimal-ui'].includes(display),
  `DISPLAY_MODE "${display}" must be one of: standalone, fullscreen, minimal-ui.`
);

const fallbackType = process.env.FALLBACK_TYPE || 'customtabs';
check(
  ['customtabs', 'webview'].includes(fallbackType),
  `FALLBACK_TYPE "${fallbackType}" must be one of: customtabs, webview.`
);

if (process.env.ICON_URL) {
  try {
    new URL(process.env.ICON_URL);
  } catch {
    errors.push(`ICON_URL "${process.env.ICON_URL}" is not a valid URL.`);
  }
}

if (errors.length) {
  console.error('❌ Input validation failed:\n');
  for (const e of errors) console.error(`  - ${e}`);
  console.error('\nFix the inputs above and re-run the workflow.');
  process.exit(1);
}

console.log('✅ All inputs valid.');

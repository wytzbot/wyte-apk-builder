/**
 * Wyte OAuth Worker
 * ------------------
 * The only job of this Worker: hold the GitHub OAuth Client Secret (which can
 * never live in the static frontend) and exchange an authorization `code`
 * for an access token on the frontend's behalf.
 *
 * Secrets (set with `wrangler secret put <NAME>`):
 *   GITHUB_CLIENT_ID
 *   GITHUB_CLIENT_SECRET
 *
 * Config (set in wrangler.toml [vars]):
 *   ALLOWED_ORIGIN   e.g. "https://your-username.github.io"
 */

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || '';
    const corsHeaders = buildCorsHeaders(origin, env.ALLOWED_ORIGIN);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (url.pathname === '/api/oauth/exchange' && request.method === 'POST') {
      return handleExchange(request, env, corsHeaders);
    }

    return json({ error: 'not_found' }, 404, corsHeaders);
  },
};

function buildCorsHeaders(origin, allowedOrigin) {
  const allow = origin === allowedOrigin ? origin : allowedOrigin;
  return {
    'Access-Control-Allow-Origin': allow,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    Vary: 'Origin',
  };
}

function json(body, status, headers) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...headers },
  });
}

async function handleExchange(request, env, corsHeaders) {
  // Reject requests from origins we don't recognize before doing any work.
  const origin = request.headers.get('Origin') || '';
  if (origin !== env.ALLOWED_ORIGIN) {
    return json({ error: 'origin_not_allowed' }, 403, corsHeaders);
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'invalid_json' }, 400, corsHeaders);
  }

  const { code, redirect_uri: redirectUri } = body || {};
  if (!code || typeof code !== 'string') {
    return json({ error: 'missing_code' }, 400, corsHeaders);
  }

  const ghResponse = await fetch('https://github.com/login/oauth/access_token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({
      client_id: env.GITHUB_CLIENT_ID,
      client_secret: env.GITHUB_CLIENT_SECRET,
      code,
      redirect_uri: redirectUri,
    }),
  });

  if (!ghResponse.ok) {
    return json({ error: 'github_exchange_failed' }, 502, corsHeaders);
  }

  const data = await ghResponse.json();

  if (data.error) {
    // e.g. bad_verification_code, incorrect_client_credentials
    return json({ error: data.error, description: data.error_description }, 400, corsHeaders);
  }

  // Only ever hand back the access token — never the client secret, never
  // anything else from GitHub's response we don't need.
  return json({ access_token: data.access_token, scope: data.scope, token_type: data.token_type }, 200, corsHeaders);
}
